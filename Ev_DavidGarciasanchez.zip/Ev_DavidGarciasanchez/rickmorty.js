document.addEventListener("DOMContentLoaded", () => {
    const charactersContainer = document.getElementById("characters-container");
  
    fetch("https://rickandmortyapi.com/api/character")
      .then((response) => response.json())
      .then((data) => {
        data.results.slice(0, 6).forEach((character) => {
          const characterCard = document.createElement("div");
          characterCard.classList.add("character-card");
  
          const image = document.createElement("img");
          image.src = character.image;
          image.alt = character.name;
          image.classList.add("character-image");
  
          const details = document.createElement("div");
          details.classList.add("character-details");
          details.innerHTML = `
            <p>Name: ${character.name}</p>
            <p>Status: ${character.status}</p>
            <p>First seen: ${character.origin.name}</p>
            <p>Last seen: ${character.location.name}</p>
            <p>Species: ${character.species}</p>
          `;
  
          characterCard.appendChild(image);
          characterCard.appendChild(details);
          charactersContainer.appendChild(characterCard);
        });
      })
      .catch((error) => console.log("Error fetching characters:", error));
  });